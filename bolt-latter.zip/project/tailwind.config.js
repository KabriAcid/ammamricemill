/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fdf9f0',
          100: '#fbf2e1',
          200: '#f6e2bd',
          300: '#efcb94',
          400: '#e6b069',
          500: '#AF792F',
          600: '#9e6b2a',
          700: '#835924',
          800: '#6b4a20',
          900: '#573d1c',
        },
        secondary: {
          50: '#f7f9f4',
          100: '#eef2e9',
          200: '#dce5d2',
          300: '#c6d4b7',
          400: '#b8c4a7',
          500: '#a0ae8f',
          600: '#8a9677',
          700: '#717a60',
          800: '#5c634f',
          900: '#4c5342',
        },
      },
      boxShadow: {
        'card-hover': '0 8px 25px -5px rgba(175, 121, 47, 0.1), 0 10px 10px -5px rgba(175, 121, 47, 0.04)',
        'card-lg': '0 25px 50px -12px rgba(175, 121, 47, 0.25)',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-out',
        'pulse-slow': 'pulse 3s infinite',
      },
    },
  },
  plugins: [],
};