import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/layout/Layout';

// Import pages
import Dashboard from './pages/Dashboard';
import GeneralSettings from './pages/settings/GeneralSettings';
import SiloList from './pages/settings/SiloList';
import GodownList from './pages/settings/GodownList';
import DesignationList from './pages/hr/DesignationList';
import EmployeeList from './pages/hr/EmployeeList';
import AttendanceList from './pages/hr/AttendanceList';
import MonthlyAttendance from './pages/hr/MonthlyAttendance';
import MonthlySalarySheet from './pages/hr/MonthlySalarySheet';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          
          {/* Settings Routes */}
          <Route path="/settings/general" element={<GeneralSettings />} />
          <Route path="/settings/silo" element={<SiloList />} />
          <Route path="/settings/godown" element={<GodownList />} />
          
          {/* HR Routes */}
          <Route path="/hr/designation" element={<DesignationList />} />
          <Route path="/hr/employee" element={<EmployeeList />} />
          <Route path="/hr/attendance" element={<AttendanceList />} />
          <Route path="/hr/attendance/monthly" element={<MonthlyAttendance />} />
          <Route path="/hr/salary" element={<MonthlySalarySheet />} />
          
          {/* Placeholder routes for remaining pages */}
          <Route path="/head-*" element={<div className="p-6">Account Heads - Coming Soon</div>} />
          <Route path="/transactions" element={<div className="p-6">Transactions - Coming Soon</div>} />
          <Route path="/party*" element={<div className="p-6">Party Management - Coming Soon</div>} />
          <Route path="/category" element={<div className="p-6">Category Management - Coming Soon</div>} />
          <Route path="/products" element={<div className="p-6">Product Management - Coming Soon</div>} />
          <Route path="/emptybag*" element={<div className="p-6">Empty Bag Management - Coming Soon</div>} />
          <Route path="/purchase*" element={<div className="p-6">Purchase Management - Coming Soon</div>} />
          <Route path="/rice-purchase*" element={<div className="p-6">Rice Purchase - Coming Soon</div>} />
          <Route path="/sales" element={<div className="p-6">Sales Management - Coming Soon</div>} />
          <Route path="/sale/ledger" element={<div className="p-6">Sales Ledger - Coming Soon</div>} />
          <Route path="/production*" element={<div className="p-6">Production Management - Coming Soon</div>} />
          <Route path="/stocks*" element={<div className="p-6">Stock Management - Coming Soon</div>} />
          <Route path="/addstocks" element={<div className="p-6">Add Stocks - Coming Soon</div>} />
          <Route path="/dailyreport" element={<div className="p-6">Daily Report - Coming Soon</div>} />
          <Route path="/financial-statement" element={<div className="p-6">Financial Statement - Coming Soon</div>} />
          <Route path="/sms-*" element={<div className="p-6">SMS Service - Coming Soon</div>} />
          <Route path="/sendsms" element={<div className="p-6">Send SMS - Coming Soon</div>} />
          <Route path="/backup" element={<div className="p-6">Database Backup - Coming Soon</div>} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;