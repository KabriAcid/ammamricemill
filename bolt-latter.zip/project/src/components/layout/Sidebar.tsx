import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  BarChart3, Settings, Users, Calculator, UserCheck, Package,
  ShoppingBag, ShoppingCart, Factory, Warehouse, FileText,
  MessageSquare, Database, ChevronDown, ChevronRight, Menu, X
} from 'lucide-react';

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  path?: string;
  children?: SidebarItem[];
}

const sidebarItems: SidebarItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: <BarChart3 className="w-5 h-5" />,
    path: '/dashboard'
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: <Settings className="w-5 h-5" />,
    children: [
      { id: 'general', label: 'General Settings', icon: null, path: '/settings/general' },
      { id: 'silo', label: 'Silo', icon: null, path: '/settings/silo' },
      { id: 'godown', label: 'Godown', icon: null, path: '/settings/godown' }
    ]
  },
  {
    id: 'hr',
    label: 'Human Resource',
    icon: <Users className="w-5 h-5" />,
    children: [
      { id: 'designation', label: 'Designation', icon: null, path: '/hr/designation' },
      { id: 'employee', label: 'Employee', icon: null, path: '/hr/employee' },
      { id: 'attendance', label: 'Attendance', icon: null, path: '/hr/attendance' },
      { id: 'monthly-attendance', label: 'Monthly Attendance', icon: null, path: '/hr/attendance/monthly' },
      { id: 'salary', label: 'Salary', icon: null, path: '/hr/salary' }
    ]
  },
  {
    id: 'accounts',
    label: 'Accounts',
    icon: <Calculator className="w-5 h-5" />,
    children: [
      { id: 'income-head', label: 'Income Head', icon: null, path: '/head-income' },
      { id: 'expense-head', label: 'Expense Head', icon: null, path: '/head-expense' },
      { id: 'bank-head', label: 'Bank Head', icon: null, path: '/head-bank' },
      { id: 'others-head', label: 'Others Head', icon: null, path: '/head-others' },
      { id: 'transactions', label: 'Transactions', icon: null, path: '/transactions' }
    ]
  },
  {
    id: 'party',
    label: 'Party',
    icon: <UserCheck className="w-5 h-5" />,
    children: [
      { id: 'party-types', label: 'Party Types', icon: null, path: '/party-types' },
      { id: 'parties', label: 'Parties', icon: null, path: '/parties' },
      { id: 'party-payments', label: 'Party Payments', icon: null, path: '/parties/payments' },
      { id: 'party-due', label: 'Party Due', icon: null, path: '/parties/due' },
      { id: 'party-debts', label: 'Party Debts', icon: null, path: '/parties/debts' }
    ]
  },
  {
    id: 'products',
    label: 'Products',
    icon: <Package className="w-5 h-5" />,
    children: [
      { id: 'category', label: 'Category', icon: null, path: '/category' },
      { id: 'products', label: 'Products', icon: null, path: '/products' }
    ]
  },
  {
    id: 'emptybags',
    label: 'Empty Bags',
    icon: <ShoppingBag className="w-5 h-5" />,
    children: [
      { id: 'emptybag-purchase', label: 'Purchase', icon: null, path: '/emptybag-purchase' },
      { id: 'emptybag-sales', label: 'Sales', icon: null, path: '/emptybag-sales' },
      { id: 'emptybag-receive', label: 'Receive', icon: null, path: '/emptybag-receive' },
      { id: 'emptybag-payment', label: 'Payment', icon: null, path: '/emptybag-payment' },
      { id: 'emptybag-stocks', label: 'Stocks', icon: null, path: '/emptybag-stocks' }
    ]
  },
  {
    id: 'purchase',
    label: 'Purchase',
    icon: <ShoppingCart className="w-5 h-5" />,
    children: [
      { id: 'purchases', label: 'Purchases', icon: null, path: '/purchases' },
      { id: 'purchase-ledger', label: 'Purchase Ledger', icon: null, path: '/purchase/ledger' },
      { id: 'rice-purchase', label: 'Rice Purchase', icon: null, path: '/rice-purchase' },
      { id: 'rice-purchase-ledger', label: 'Rice Purchase Ledger', icon: null, path: '/ricepurchase/ledger' }
    ]
  },
  {
    id: 'sales',
    label: 'Sales',
    icon: <Package className="w-5 h-5" />,
    children: [
      { id: 'sales', label: 'Sales', icon: null, path: '/sales' },
      { id: 'sale-ledger', label: 'Sale Ledger', icon: null, path: '/sale/ledger' }
    ]
  },
  {
    id: 'production',
    label: 'Production',
    icon: <Factory className="w-5 h-5" />,
    children: [
      { id: 'productions', label: 'Productions', icon: null, path: '/productions' },
      { id: 'production-details', label: 'Production Details', icon: null, path: '/production/details' }
    ]
  },
  {
    id: 'stocks',
    label: 'Stocks',
    icon: <Warehouse className="w-5 h-5" />,
    children: [
      { id: 'stocks', label: 'Stocks', icon: null, path: '/stocks' },
      { id: 'stocks-godown', label: 'Stocks Godown', icon: null, path: '/stocks-godown' },
      { id: 'stocks-details', label: 'Stock Details', icon: null, path: '/stocks/details' },
      { id: 'add-stocks', label: 'Add Stocks', icon: null, path: '/addstocks' },
      { id: 'production-stocks', label: 'Production Stocks', icon: null, path: '/production-stocks' },
      { id: 'production-stock-details', label: 'Production Stock Details', icon: null, path: '/production-stock/details' }
    ]
  },
  {
    id: 'reporting',
    label: 'Reporting',
    icon: <FileText className="w-5 h-5" />,
    children: [
      { id: 'daily-report', label: 'Daily Report', icon: null, path: '/dailyreport' },
      { id: 'financial-statement', label: 'Financial Statement', icon: null, path: '/financial-statement' }
    ]
  },
  {
    id: 'sms',
    label: 'SMS Service',
    icon: <MessageSquare className="w-5 h-5" />,
    children: [
      { id: 'sms-templates', label: 'SMS Templates', icon: null, path: '/sms-templates' },
      { id: 'send-sms', label: 'Send SMS', icon: null, path: '/sendsms' }
    ]
  },
  {
    id: 'backup',
    label: 'Database Backup',
    icon: <Database className="w-5 h-5" />,
    path: '/backup'
  }
];

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState<string[]>(['settings']);

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev =>
      prev.includes(itemId)
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const isPathActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  const renderSidebarItem = (item: SidebarItem, level = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.id);
    const isActive = item.path ? isPathActive(item.path) : false;
    const hasActiveChild = item.children?.some(child => child.path && isPathActive(child.path));

    return (
      <div key={item.id}>
        {item.path ? (
          <Link
            to={item.path}
            className={`flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive
                ? 'bg-primary-100 text-primary-700 border-r-2 border-primary-500'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
            style={{ paddingLeft: `${(level + 1) * 16}px` }}
          >
            {item.icon}
            <span className="ml-3 flex-1">{item.label}</span>
          </Link>
        ) : (
          <button
            onClick={() => toggleExpanded(item.id)}
            className={`w-full flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              hasActiveChild
                ? 'bg-primary-50 text-primary-700'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
            style={{ paddingLeft: `${(level + 1) * 16}px` }}
          >
            {item.icon}
            <span className="ml-3 flex-1 text-left">{item.label}</span>
            {hasChildren && (
              isExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )
            )}
          </button>
        )}
        
        {hasChildren && isExpanded && (
          <div className="ml-4">
            {item.children!.map(child => renderSidebarItem(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
          <h1 className="text-xl font-bold text-primary-600">Rice Mill ERP</h1>
          <button
            onClick={onToggle}
            className="lg:hidden p-2 rounded-md hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <nav className="mt-5 px-2 space-y-1 h-full overflow-y-auto pb-4">
          {sidebarItems.map(item => renderSidebarItem(item))}
        </nav>
      </div>
    </>
  );
};